// 1. 해상도 및 프레임레이트 최대화 (FHD ~ 4K 강제 요청)
function upgradeResolution() {
  if (window.navigator && window.navigator.mediaDevices) {
    const origGetUserMedia = window.navigator.mediaDevices.getUserMedia.bind(window.navigator.mediaDevices);
    
    window.navigator.mediaDevices.getUserMedia = function(constraints) {
      if (constraints && constraints.video) {
        // 비디오 트랙이 존재할 경우 FHD/4K 및 60fps 조건 주입
        if (typeof constraints.video === 'object') {
          constraints.video.width = { ideal: 3840, min: 1920 };
          constraints.video.height = { ideal: 2160, min: 1080 };
          constraints.video.frameRate = { ideal: 60, min: 30 };
        } else {
          constraints.video = {
            width: { ideal: 3840, min: 1920 },
            height: { ideal: 2160, min: 1080 },
            frameRate: { ideal: 60, min: 30 }
          };
        }
      }
      return origGetUserMedia(constraints);
    };
  }
}

// 전체화면 토글 함수
function toggleFullscreen(element) {
  if (!document.fullscreenElement) {
    element.requestFullscreen().catch(err => {
      console.error("MeetScreen 전체화면 오류:", err.message);
    });
  } else {
    document.exitFullscreen();
  }
}

// 2. 더블클릭 이벤트 차단 우회 및 감지
function initExtension() {
  // 해상도 조작 적용
  upgradeResolution();

  // 비디오 위에 투명 레이어가 있어도 감지할 수 있도록 window 객체에 캡처링 모드(true)로 등록
  window.addEventListener('dblclick', (event) => {
    // 1순위: 마우스 위치 아래에 있는 비디오 요소를 좌표 기반으로 직접 탐색 (투명 레이어 우회)
    const elementsAtPoint = document.elementsFromPoint(event.clientX, event.clientY);
    let videoElement = elementsAtPoint.find(el => el.tagName === 'VIDEO');

    // 2순위: 찾지 못했다면 가장 가까운 비디오나 화면에서 가장 큰 발표 화면 비디오 탐색
    if (!videoElement) {
      const videos = document.querySelectorAll('video');
      if (videos.length > 0) {
        let maxArea = 0;
        videos.forEach(v => {
          const area = v.clientWidth * v.clientHeight;
          if (area > maxArea) {
            maxArea = area;
            videoElement = v;
          }
        });
      }
    }

    // 전체화면 실행
    if (videoElement) {
      event.preventDefault();
      event.stopPropagation();
      toggleFullscreen(videoElement);
    }
  }, true); // true 설정을 통해 다른 스크립트가 이벤트를 가로채기 전에 먼저 실행함

  // 오류를 유발할 수 있는 특수문자를 제거한 안전한 콘솔 출력
  console.log("===============================");
  console.log("MeetScreen Loaded Successfully!");
  console.log("===============================");
}

// 초기화 실행
initExtension();
